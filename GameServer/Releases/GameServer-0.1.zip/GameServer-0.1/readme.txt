﻿This is a .NET Core 3.1 application, it requires the .Net Core 3.1 Runtime to be installed.
Change settings.json to point at your Aoe2 WK installation. Speed is the speedhack (10 = normal speed)
Run GameServer.exe
You will be requested for the password to upload games to the ladder. Leave blank to run in local mode.
It is suggested to first try out the game server in local mode to see if everything works, it will not upload the games at the end.
The game server will get the ranking and zips from the ladder, start aoe2, run a random game, close aoe2, upload the result to the ladder, and rinse and repeat.
