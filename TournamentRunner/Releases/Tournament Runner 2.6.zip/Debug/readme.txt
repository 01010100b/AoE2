﻿- Check here for the values of the parameters: https://github.com/FLWL/aoc-auto-game

- All fields must have values, if a player slot isn't used then set it to "Closed" "0" "0"

- Do not touch the aoe2 windows that pop up, your mouse will be captured and it may even block the games in other windows from continuing

- Results are given as: "Result after game i/total: g1 g2 g3 g4 g5 g6 g7 g8 - t1 t2 t3 t4" 
with g1, g2, ... the number of games won for player1, player2, ... and t1, t2, ... the number of games won for team1, team2, ...
