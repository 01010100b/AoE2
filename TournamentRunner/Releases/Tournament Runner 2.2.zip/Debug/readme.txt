﻿- Check here for the values of the parameters: https://github.com/FLWL/aoc-auto-game
- All fields must have values, if a player slot isn't used then set it to "Closed" "0" "0"
- Do not touch the aoe2 windows that pop up, they will minimize when games are started
- Results are given as: "Result after game i/total: g1 g2 g3 g4 g5 g6 g7 g8" with g1, g2, ... the number of games won for player1, player2, ...
